# Four Display Studio

Android source project for four Merkury Innovations 16×16 LED displays. Unified sequence editor, persistent local sequence library, native Bluetooth LE upload, and a GitHub Actions APK build.

## Status

Generated first implementation, based on the supplied `index4.html` controller. Not compiled or hardware-tested in the generation environment. The build workflow must succeed before an APK exists. Device connection, MTU negotiation and uploads require testing on your phone/displays. No promise of synchronization, read-back verification, storage capacity, or hardware timing control is made.

## Upload to GitHub from your phone

1. Extract this ZIP in your Files app.
2. In your new GitHub repository, choose Add file → Upload files. Upload the extracted CONTENTS, not this ZIP, and commit. `settings.gradle`, `build.gradle`, `app/`, and `.github/` belong at repository root, without an extra enclosing folder.
3. Verify `.github/workflows/build.yml` exists in the repository. Dot-folders can be hidden by phone file pickers. If it is missing, choose Add file → Create new file, enter `.github/workflows/build.yml` as the name, and paste the contents from the extracted workflow. Do the same for other missing nested files. GitHub's desktop-site browser view may help.
4. Open Actions → Build APK → Run workflow. A push to main/master also starts it. Allow Actions if prompted. If using another branch, run manually from the branch containing the workflow (manual dispatch availability depends on the workflow being on the default branch).
5. Wait for a successful build. Download the `FourDisplayStudio-apk` artifact at the bottom of that run. Extract the downloaded artifact ZIP and open `app-debug.apk`. Allow installation from that source if Android asks.
6. If the build fails, share the error text from the failed step; no successful compilation has yet been verified here.

This workflow uses standard Ubuntu runners, Java 17, Gradle 8.9, Android Gradle Plugin 8.7.3, and SDK 35. No Gradle wrapper binary is needed for this workflow. For local development use those versions and `gradle :app:assembleDebug`.

## First use

1. Turn on Bluetooth. Open Displays → Scan / assign for display 1. Grant Bluetooth permissions and tap again if prompted. On Android 8–11, grant location permission and enable system Location if scanning is empty.
2. Choose your own display, then repeat for the remaining three. Do not assign one device to two slots. For a 2×2 wall, order is top-left, top-right, bottom-left, bottom-right.
3. Wait for all four to report Ready. MTU must be at least 104 because the supplied protocol writes 101-byte image blocks. The app requests a larger MTU and refuses oversized writes; it does not invent alternate fragmentation.
4. Select the physical arrangement in Editor. Each panel is 16×16; a 2×2 wall is 32×32. Four across is 64×16, four stacked is 16×64.
5. Import a whole-wall image to split across the four panels, or import an image separately into any panel. Each sequence step always has four images; empty slots send black. You can mix approaches in any order.
6. Add, duplicate, delete, or reorder steps. Choose fit, fill/crop, or stretch before import. Changing layout rearranges already split tiles; reimport a wall image to resplit.
7. Name and Save sequence. The library stores its own PNG copies, so the gallery is not needed for later playback/upload. Save is explicit, not automatic.
8. Start with 1–2 distinctive images. Replace stored slideshows erases ALL FOUR displays after confirmation. Append keeps existing images, which can leave unequal lists if displays already differed. Hardware capacity is unknown; the 200-step app limit is not a hardware capacity claim.
9. Keep the app visible and your phone nearby until completion. Upload completes one display at a time while keeping the four connections. When done, press Start all slideshows. Hardware timing is not configurable here. Per-step durations affect phone preview only.

Replacing cannot be rolled back. A partial failure can leave displays with different or incomplete lists. Cancel stops further commands but cannot undo storage changes. Disconnecting also cancels. Closing the app or OS termination can interrupt uploads; there is no background service or resume. Screen stays awake during transfer while the activity remains visible.

## Saved library and backups

Library supports open, rename, duplicate, delete, plus export/import. Export creates a JSON file using Android's document picker with all SAVED sequences and image copies; Bluetooth addresses are omitted. Save current edits before export. Import merges copies into your library and does not overwrite existing sequences. Keep backups outside app storage. Device assignments are local and saved separately.

Uninstalling or clearing app data removes saved sequences/assignments. Android automatic backup is disabled. Import files are limited to 40 MB; image inputs to 20 MB; per-sequence steps to 200. Very large decoded images may exceed phone memory. Static image imports only, not timed GIF playback.

## Signing and later updates — important

Without signing secrets each clean build uses a generated debug key, so a later APK may not install over an earlier APK. BEFORE uninstalling, export your library. Reinstall, then import the backup. Do not rely on an unexported library in this first build.

Optional stable signing: create and privately retain an Android signing keystore. In repository Settings → Secrets and variables → Actions, configure:

- ANDROID_KEYSTORE_BASE64: base64-encoded keystore file
- ANDROID_KEYSTORE_PASSWORD: store password
- ANDROID_KEY_ALIAS: alias
- ANDROID_KEY_PASSWORD: key password

The workflow decodes the key into the temporary runner directory, not the repository or APK artifact. Keep the same key for updates. Never upload the keystore or passwords as ordinary repository files. Changing from default debug signing to a stable key also requires reinstall/backup. This package does not generate a permanent keystore for you.

## Protocol implementation

Uses the attached HTML's service FFD0, characteristic FFD1, RGB row-major 768-byte tiles, eight 101-byte image packets, checksum, commands and delays. `PROTOCOL.md` documents these. Native writes prefer write-without-response if supported, matching the supplied HTML. Android write callbacks indicate local transport completion, not application-layer storage verification. No retries after a partially sent frame: the operation stops and reports the error to avoid blindly duplicating storage commands.

## Privacy and permissions

No Internet permission, server, analytics, account or cloud storage. Images use Android's picker, not broad gallery permission. Bluetooth permissions requested when needed; location permission is restricted to Android 8–11 BLE scanning. Scan lists all nearby BLE devices, not only compatible hardware. Assign only devices you own. Logs can contain device addresses; redact before sharing. Devices using changing addresses may require reassignment. Exported backups contain your images in plaintext; store them appropriately.

## Credits

- [offe (Oscar Lindberg)](https://github.com/offe), for [mi-led-display](https://github.com/offe/mi-led-display), reverse engineering of the Merkury Innovations display protocol.
- [skyline46](https://github.com/skyline46), acknowledged at the project owner's request.
- The supplied `index4.html` controller is the direct protocol reference for this implementation. Its original contents are included in `reference/index4.html` for traceability, not executed by the Android app.
- Initial Android project generated with Perplexity; compilation and hardware behavior need verification.

No endorsement by credited people is implied. See THIRD_PARTY_NOTICES.md for attribution and licensing limitations.
